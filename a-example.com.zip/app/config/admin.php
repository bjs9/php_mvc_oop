<?php

return ['alogin' => '$2y$10$G7if1ZcOAS4AruI9bpbfWOmQGdvHgPSsMl1v4sEDUC97iUpragWd6', 'apass' => '$2y$10$q7I0antQ5jXaaXUBvKvMjObGmja.7kX5EExtHpySdQrs9Ekq1IWve'];