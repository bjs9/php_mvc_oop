<?php

return [
	'' => [
		'controller' => 'main',
		'action'     => 'index',
		'title'      => 'Index Page'
	],

	'test' => [
		'controller' => 'main',
		'action'     => 'test',
		'title'      => 'Test Page'
	]
];

