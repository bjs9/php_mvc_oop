<?php include "app/views/inc/header.php" ?>
<?php include "app/views/inc/navbar.php" ?>
<?= $content ?>
<?php include "app/views/inc/footer.php" ?>