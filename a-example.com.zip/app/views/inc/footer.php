    <script src="/public/js/main.js"></script>
    
    </body>
</html>