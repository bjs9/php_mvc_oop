<?php

namespace app\models;

use core\Model;

class Main extends Model {
	
}