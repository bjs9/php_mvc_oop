<?php

namespace app\models;

use core\Model;

class Admin extends Model {

}