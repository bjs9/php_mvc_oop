<?php

namespace app\controllers;

use core\Controller;

class AdminController extends Controller {

	public function indexAction() {
		
	}
}

