# PHP MVC Mini Framework

A mini-framework built with pure PHP using the MVC architecture.  
Custom routing system, templating, and multilingual support.
