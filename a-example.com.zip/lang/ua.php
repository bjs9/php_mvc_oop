<?php

return [
    'test_msg' => 'Привіт світ!'
];