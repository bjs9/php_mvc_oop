<?php

return [
    'test_msg' => 'Hello world!'
];